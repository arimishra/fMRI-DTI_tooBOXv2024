VUIIS ImageProcessing package (vuTools)
Copyright (c) 2012 Vanderbilt University
Version 2012

INSTALLATION
============
- Unzip file in desired location  
- Open Matlab
- Under File->Set Path 
- Click Add with Subfolders...
- Select vuTools folder, click Open
- Click Save, Click Close
- Start using the package!

SAMPLE DATA - for wiki examples
===========
- Download SampleData.zip from wiki
- Unzip this directory somewhere sensible.
- Open Matlab
- Under File->Set Path 
- Click Add with Subfolders...
- Select vuTools folder, click Open
- Click Save, Click Close

All tools begin with vu, so typing 'vu' at the Matlab command prompt, then pressing 'tab' will bring up the list of available files.

For more information go to http://wiki.vuiis.vanderbilt.edu/index.php/VUIIS_Matlab_Image_Processing_Tools